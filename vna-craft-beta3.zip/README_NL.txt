VNA-craft - Copper Mountain TR1300/1

Installatie
1. Installeer Python 3.10 of nieuwer voor Windows.
2. Controleer in TRVNA via Help > About dat versie 24.2.2 is geïnstalleerd.
3. Sluit de TRVNA-software niet; open de gewenste S21-meting en activeer
   de gewenste marker/bandwidth search.
4. Voer install.bat uit als administrator indien Python dat vereist.

Gebruik
1. Start TRVNA en daarna start_qmax.bat.
2. Kies channel, marker en uitleesinterval (standaard 0,01 s).
3. Vul vóór Start de coilnaam in.
4. Kies bij Trigger `BUS` of `INT` en klik Verbinden. Klik daarna Start
   registratie en Stop wanneer gewenst.
5. Bij Stop worden CSV en Excel automatisch opgeslagen in de map `metingen`
   naast het programma, bijvoorbeeld `metingen\coil_20261116_181530.csv`.
   De handmatige exportknoppen blijven ook beschikbaar.

Bij Verbinden wordt de triggerbron expliciet ingesteld op BUS of INT
(`TRIGger:SEQuence:SOURce BUS` of `INT`). Bij BUS voert elk meetpunt precies één
`TRIGger:SEQuence:SINGle` uit, leest daarna de markerdata uit en plant pas
daarna het volgende meetpunt.

Technische beperking
De applicatie gebruikt de late-bound automatiseringsketen
TRVNA.Application -> SCPI.GetCALCulate(channel).SELected.GetMARKer(marker).BWIDth.DATA.
De verwachte volgorde is bandwidth, center frequency, Q en loss. De fysieke
USB/COM-koppeling is getest met TRVNA 24.2.2 en een aangesloten TR1300/1.
Bij een afwijkende build verschijnt mogelijk een foutmelding; de applicatie
doet dan geen aannames of eigen Q-berekening.

Een directe test op de gebruikte computer vond:
TRVNA.Application = TR1300/1, 24.2.2/1.0, en een geldige COM-verbinding.
Voor channel 1/marker 1 gaf DATA=(0, 0, 0, -0.0578). Ook deze nulwaarden
worden door de applicatie als meetpunt geregistreerd en in de grafiek getoond.
Niet-finite waarden worden wel geweigerd.
De interface gebruikt een zwart theme. De middenfrequentie en bandwidth worden
in MHz weergegeven en geëxporteerd. Exportkolommen hebben een vaste
standaardbreedte. De interface toont ook de frequentie die bij Qmax hoort.
Daarnaast toont de interface het gemiddelde van de maximaal drie hoogste
Q-metingen. Als er minder dan drie meetpunten zijn, worden de beschikbare
meetpunten gemiddeld.
In CSV en Excel wordt het bijbehorende meetpunt gemarkeerd met `is_qmax`.
Na een uitleesfout stopt de registratie; maximaal twee foutmeldingen worden
getoond, zodat achtergebleven COM-fouten geen popup-loop veroorzaken.

Getoonde waarden gebruiken twee cijfers achter de komma. De geëxporteerde
meetdata blijft ongewijzigd nauwkeurig.

Headless uitvoeren
Gebruik vanuit PowerShell:
`py -3 qmax_monitor.py --headless --interval 0.01 --output meting.csv`
Optioneel zijn `--channel`, `--marker` en `--trigger BUS|INT`. De registratie stopt met Ctrl+C;
daarna wordt de CSV automatisch opgeslagen.
Met `start_qmax_headless.bat` kan dit ook direct worden gestart.

Alle COM-aanroepen lopen op één workerthread met CoInitialize/CoUninitialize.
