@echo off
py -3 qmax_monitor.py --headless --interval 0.01 --output qmax_headless.csv
if errorlevel 1 pause
