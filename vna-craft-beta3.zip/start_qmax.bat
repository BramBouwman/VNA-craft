@echo off
py -3 qmax_monitor.py
if errorlevel 1 pause
